export default abstract class Exclusao {
    public abstract deletar(): void;
}
