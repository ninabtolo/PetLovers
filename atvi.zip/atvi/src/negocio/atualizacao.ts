export default abstract class Atualizacao {
    public abstract atualizar(): void;
}
