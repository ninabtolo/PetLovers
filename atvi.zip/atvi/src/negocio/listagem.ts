export default abstract class Listagem {
    public abstract listar(): void
}