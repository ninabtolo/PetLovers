export default abstract class Cadastro {
    public abstract cadastrar(): void
}